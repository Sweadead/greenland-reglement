# GREENLAND RUST

Site officiel du serveur Greenland Rust.

## Modifier les liens

Ouvre `index.html` et remplace le lien du bouton Discord :

```html
<a class="discord-btn" href="#">Discord</a>
```

par ton lien Discord.
